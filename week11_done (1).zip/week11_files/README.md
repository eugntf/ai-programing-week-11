# load_scores — 성적 CSV 읽기 도구

## ① 무엇을 하나요 (What)

성적 CSV를 읽어 유효한 (이름, 점수)만 골라 내고, 건너뛴 줄은 이유와 함께 기록합니다.

## ② 왜 만들었나요 (Why)

<!-- ★ 직접 쓰세요: 실제 파일에서 겪은 문제를 두세 문장으로. 아래는 뼈대 예시입니다. -->
(예) 실제 성적 파일에는 빈 점수 · 범위 밖 점수 · 열 개수가 다른 줄이 섞여 있어, 그냥 읽으면 프로그램이 죽거나 틀린 평균이 나옵니다. 그래서 문제 줄은 건너뛰되 어느 줄을 왜 건너뛰었는지 남기는 도구가 필요했습니다.

## ③ 어떻게 쓰나요 (How)

```bash
# 설치 (표준 라이브러리만 사용, 테스트용으로만 pytest 필요)
pip install pytest pytest-cov

# 실행
python load_scores.py scores.csv
```

## ④ 어떻게 테스트하나요

```bash
pytest test_load_scores.py test_fixed.py -q
pytest test_load_scores.py --cov=load_scores --cov-report=term-missing
```

```
<!-- 본인 컴퓨터에서 실행한 통과 화면으로 바꿔 붙이세요 -->
49 passed
load_scores.py   45   0   100%
```

## ⑤ 파일 구성

| 파일 | 하는 일 |
| --- | --- |
| load_scores.py | CSV를 읽어 (kept, skipped) 반환 |
| test_load_scores.py | load_scores 단위 테스트 (정상·예외·경계값) |
| bug3_logic.py | find_max / count_pass (버그 수정본) |
| test_fixed.py | bug3_logic 회귀 테스트 (경계값 60 포함) |
| helpers.py | 경계값 테스트용 CSV 생성 도우미 |
| scores.csv · weird.csv · empty.csv | 시험용 입력 파일 |

## ⑥ 만든 사람 · AI를 어디에 썼는지

- 만든 사람 : (이름 · 학번)
- AI를 쓴 곳 : (예: 테스트 코드 초안 작성)
- 내가 직접 판단한 것 : (예: 동명이인을 지우지 않고 둘 다 남기기로 한 것, 어떤 경계값을 넣을지)

## 라이선스

MIT License (LICENSE 파일 참고)
