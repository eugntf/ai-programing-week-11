# test_fixed.py — bug3_logic.py 회귀 검증 (경계값 60 포함)
import io, contextlib
with contextlib.redirect_stdout(io.StringIO()):   # 모듈 맨 아래 print 가 시끄러우므로 가림
    from bug3_logic import find_max, count_pass


# ---- find_max : 마지막 원소까지 봐야 한다 ----
def test_find_max_원래_데이터():
    assert find_max([70, 85, 60, 95]) == 95

def test_find_max_최고점이_맨_끝():
    assert find_max([10, 20, 30]) == 30

def test_find_max_최고점이_맨_앞():
    assert find_max([95, 85, 70, 60]) == 95

def test_find_max_원소_하나():
    assert find_max([42]) == 42

def test_find_max_원소_둘_끝이_더_큼():
    assert find_max([1, 2]) == 2

def test_find_max_음수와_중복():
    assert find_max([-5, -1, -1, -9]) == -1


# ---- count_pass : cutoff 점 "이상"이 합격 ----
def test_count_pass_원래_데이터():
    assert count_pass([70, 85, 60, 95]) == 4

def test_count_pass_경계값_60_자체():
    assert count_pass([60]) == 1

def test_count_pass_경계_바로_아래():
    assert count_pass([59]) == 0

def test_count_pass_경계_근처_섞기():
    assert count_pass([60, 60, 59]) == 2

def test_count_pass_cutoff_바꾸기():
    assert count_pass([70, 80, 69], cutoff=70) == 2

def test_count_pass_빈_리스트():
    assert count_pass([]) == 0
