# test_load_scores.py — 내가 만든 테스트 (명세 ①~⑥ + 동명이인 + 빈 줄 + 경계값)
import pytest
from load_scores import load_scores
from helpers import 쓰기


def _csv(tmp_path, text, name="t.csv"):
    p = tmp_path / name
    p.write_text(text, encoding="utf-8")
    return str(p)


# ---------- 정상 ----------
def test_정상_한_명(tmp_path):
    p = _csv(tmp_path, "name,score\n홍길동,80\n")
    assert load_scores(p) == ([("홍길동", 80)], [])


def test_정상_여러_명_순서_유지(tmp_path):
    p = _csv(tmp_path, "name,score\n가,1\n나,2\n다,3\n")
    kept, skipped = load_scores(p)
    assert kept == [("가", 1), ("나", 2), ("다", 3)]
    assert skipped == []


def test_BOM_있는_파일(tmp_path):
    p = tmp_path / "bom.csv"
    p.write_bytes("\ufeffname,score\n홍길동,90\n".encode("utf-8"))
    assert load_scores(str(p)) == ([("홍길동", 90)], [])


def test_따옴표_안_쉼표_이름은_한_칸(tmp_path):
    p = _csv(tmp_path, 'name,score\n"최,네번",77\n')
    assert load_scores(p) == ([("최,네번", 77)], [])


def test_앞뒤_공백은_잘라서_받는다(tmp_path):
    p = _csv(tmp_path, "name,score\n  홍길동 ,  77\n")
    assert load_scores(p) == ([("홍길동", 77)], [])


# ---------- ① 파일 없음 ----------
def test_파일이_없으면_FileNotFoundError(tmp_path):
    with pytest.raises(FileNotFoundError):
        load_scores(str(tmp_path / "없는파일.csv"))


# ---------- ② 헤더만 ----------
def test_헤더만_있으면_빈_결과(tmp_path):
    assert load_scores(_csv(tmp_path, "name,score\n")) == ([], [])


def test_완전히_빈_파일(tmp_path):
    assert load_scores(_csv(tmp_path, "")) == ([], [])


# ---------- ③ 열 개수 ----------
@pytest.mark.parametrize("line", ["홍길동", "홍길동,80,비고", "a,b,c,d"])
def test_열_개수가_2가_아니면_건너뜀(tmp_path, line):
    kept, skipped = load_scores(_csv(tmp_path, f"name,score\n{line}\n"))
    assert kept == []
    assert len(skipped) == 1
    assert skipped[0][0] == 2
    assert "열 개수" in skipped[0][2]


# ---------- ④ 점수가 비었거나 정수 아님 ----------
def test_점수가_비면_건너뜀(tmp_path):
    kept, skipped = load_scores(_csv(tmp_path, "name,score\n홍길동,\n"))
    assert kept == []
    assert skipped == [(2, "홍길동,", "점수가 비어 있음")]


def test_공백뿐인_점수도_빈_것으로_본다(tmp_path):
    kept, skipped = load_scores(_csv(tmp_path, "name,score\n홍길동,   \n"))
    assert kept == [] and "비어" in skipped[0][2]


@pytest.mark.parametrize("raw", ["결석", "88.5", "7 2", "1e2", "0x10", "abc"])
def test_점수가_정수가_아니면_건너뜀(tmp_path, raw):
    kept, skipped = load_scores(_csv(tmp_path, f"name,score\n홍길동,{raw}\n"))
    assert kept == []
    assert "정수가 아님" in skipped[0][2]


# ---------- ⑤ 범위 / 경계값 ----------
@pytest.mark.parametrize("score", [0, 1, 99, 100])
def test_경계_안쪽은_통과(tmp_path, score):
    p = str(tmp_path / "b.csv")
    쓰기(p, score)
    assert load_scores(p) == ([("홍길동", score)], [])


@pytest.mark.parametrize("score", [-1, 101, -100, 1000])
def test_경계_바깥은_건너뜀(tmp_path, score):
    p = str(tmp_path / "b.csv")
    쓰기(p, score)
    kept, skipped = load_scores(p)
    assert kept == []
    assert skipped[0][2] == "점수가 0~100 밖"


# ---------- ⑥ 이름 ----------
def test_이름이_비면_건너뜀(tmp_path):
    kept, skipped = load_scores(_csv(tmp_path, "name,score\n,90\n"))
    assert kept == []
    assert skipped == [(2, ",90", "이름이 비어 있음")]


def test_이름이_공백뿐이어도_건너뜀(tmp_path):
    kept, skipped = load_scores(_csv(tmp_path, "name,score\n   ,90\n"))
    assert kept == [] and "이름" in skipped[0][2]


# ---------- 동명이인: 지우지 않고 둘 다 남김 ----------
def test_같은_이름은_둘_다_남긴다(tmp_path):
    p = _csv(tmp_path, "name,score\n김하나,88\n김하나,91\n")
    kept, skipped = load_scores(p)
    assert kept == [("김하나", 88), ("김하나", 91)]
    assert skipped == []


# ---------- 빈 줄 ----------
def test_빈_줄은_기록_없이_건너뜀(tmp_path):
    p = _csv(tmp_path, "name,score\n\n홍길동,80\n\n")
    kept, skipped = load_scores(p)
    assert kept == [("홍길동", 80)]
    assert skipped == []


# ---------- 줄 번호 / 반환 형태 ----------
def test_줄번호는_헤더를_1로_세고_빈줄도_센다(tmp_path):
    p = _csv(tmp_path, "name,score\n가,1\n\n나,200\n")
    _, skipped = load_scores(p)
    assert skipped[0][0] == 4


def test_반환은_튜플_두_개짜리(tmp_path):
    result = load_scores(_csv(tmp_path, "name,score\n"))
    assert isinstance(result, tuple) and len(result) == 2


# ---------- 실제 샘플 파일 (같은 폴더의 CSV) ----------
def test_scores_csv_전체():
    kept, skipped = load_scores("scores.csv")
    assert len(kept) == 5
    assert len(skipped) == 5
    assert [s[0] for s in skipped] == [3, 4, 7, 8, 9]


def test_weird_csv_전체():
    kept, skipped = load_scores("weird.csv")
    assert kept == [("한겨울", 77), ("윤보람", 88)]
    assert len(skipped) == 7


def test_empty_csv():
    assert load_scores("empty.csv") == ([], [])


# ---------- 명령줄 실행부 (__main__) ----------
def test_명령줄로_실행하면_요약을_출력한다(capsys, monkeypatch):
    import runpy
    monkeypatch.setattr("sys.argv", ["load_scores.py", "scores.csv"])
    runpy.run_path("load_scores.py", run_name="__main__")
    out = capsys.readouterr().out
    assert "읽은 줄 : 5개" in out
    assert "건너뛴 줄 : 5개" in out
